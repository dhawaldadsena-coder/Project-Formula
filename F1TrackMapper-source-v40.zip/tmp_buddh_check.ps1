function Parse-Path([string]$d){
  $tokens = [regex]::Matches($d,'[A-Za-z]|[-+]?\d*\.?\d+(?:[eE][-+]?\d+)?') | ForEach-Object { $_.Value }
  $pts = New-Object System.Collections.Generic.List[object]
  $cmd = $null; $i=0; $cx=0.0; $cy=0.0; $sx=0.0; $sy=0.0
  while($i -lt $tokens.Count){
    $t = $tokens[$i]
    if($t -match '^[A-Za-z]$'){
      $cmd = $t
      $i++
      if($cmd -eq 'Z' -or $cmd -eq 'z'){ $cx=$sx; $cy=$sy; $pts.Add(@($cx,$cy)) }
      continue
    }
    switch($cmd){
      'm' { $cx += [double]$tokens[$i]; $cy += [double]$tokens[$i+1]; $sx=$cx; $sy=$cy; $pts.Add(@($cx,$cy)); $i += 2; $cmd='l'; continue }
      'M' { $cx = [double]$tokens[$i]; $cy = [double]$tokens[$i+1]; $sx=$cx; $sy=$cy; $pts.Add(@($cx,$cy)); $i += 2; $cmd='L'; continue }
      'l' { $cx += [double]$tokens[$i]; $cy += [double]$tokens[$i+1]; $pts.Add(@($cx,$cy)); $i += 2; continue }
      'L' { $cx = [double]$tokens[$i]; $cy = [double]$tokens[$i+1]; $pts.Add(@($cx,$cy)); $i += 2; continue }
      'h' { $cx += [double]$tokens[$i]; $pts.Add(@($cx,$cy)); $i++; continue }
      'H' { $cx = [double]$tokens[$i]; $pts.Add(@($cx,$cy)); $i++; continue }
      'v' { $cy += [double]$tokens[$i]; $pts.Add(@($cx,$cy)); $i++; continue }
      'V' { $cy = [double]$tokens[$i]; $pts.Add(@($cx,$cy)); $i++; continue }
      default { throw "Unsupported command: $cmd" }
    }
  }
  return $pts
}

function Bounds($pts){
  $xs = $pts | ForEach-Object { $_[0] }
  $ys = $pts | ForEach-Object { $_[1] }
  [PSCustomObject]@{
    MinX = ($xs | Measure-Object -Minimum).Minimum
    MaxX = ($xs | Measure-Object -Maximum).Maximum
    MinY = ($ys | Measure-Object -Minimum).Minimum
    MaxY = ($ys | Measure-Object -Maximum).Maximum
    Width = (($xs | Measure-Object -Maximum).Maximum - ($xs | Measure-Object -Minimum).Minimum)
    Height = (($ys | Measure-Object -Maximum).Maximum - ($ys | Measure-Object -Minimum).Minimum)
  }
}

$svg = Get-Content -Raw -Path 'buddh_circuit.svg'
foreach($id in @('path5880','path5666')){
  $m = [regex]::Match($svg,"d=\"([^\"]+)\" id=\"$id\"")
  if(-not $m.Success){ Write-Output "$id: missing"; continue }
  $pts = Parse-Path $m.Groups[1].Value
  $b = Bounds $pts
  Write-Output "$id points=$($pts.Count) width=$([math]::Round($b.Width,2)) height=$([math]::Round($b.Height,2))"
}
